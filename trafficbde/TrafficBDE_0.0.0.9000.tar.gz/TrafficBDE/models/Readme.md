This folder contains the trained models
